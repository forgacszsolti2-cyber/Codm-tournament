import { useState, useEffect } from "react";

function generateBracket(players) {
  const shuffled = [...players].sort(() => Math.random() - 0.5);
  const round = [];
  for (let i = 0; i < shuffled.length; i += 2) {
    round.push({
      p1: shuffled[i],
      p2: shuffled[i + 1] || null,
      winner: null
    });
  }
  return [round];
}

export default function App() {
  const [players, setPlayers] = useState([
    "Player1","Player2","Player3","Player4"
  ]);

  const [bracket, setBracket] = useState([]);

  const create = () => {
    setBracket(generateBracket(players));
  };

  const setWinner = (ri, mi, winner) => {
    const copy = [...bracket];
    copy[ri][mi].winner = winner;
    setBracket(copy);
  };

  return (
    <div style={{ padding: 20, fontFamily: "Arial", background: "#111", color: "white", minHeight: "100vh" }}>
      <h1>CODM Tournament</h1>

      <button onClick={create}>Generate Bracket</button>

      {bracket.map((round, ri) => (
        <div key={ri}>
          <h2>Round {ri + 1}</h2>

          {round.map((m, mi) => (
            <div key={mi} style={{ marginBottom: 10, padding: 10, border: "1px solid #444" }}>
              <div>{m.p1} vs {m.p2 || "BYE"}</div>

              <button onClick={() => setWinner(ri, mi, m.p1)}>P1 wins</button>
              <button onClick={() => setWinner(ri, mi, m.p2)}>P2 wins</button>

              {m.winner && <div>Winner: {m.winner}</div>}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
